(async () => {
    const localStorage = await chrome.storage.local.get();
    if (localStorage["defaultSettingsUrl"] == null) {
        await chrome.storage.local.set({ defaultSettingsUrl: "https://www.google.com/" });
    }

    let BOEnabled = false;
    let alertThrown = false;
    let BORunning = false;
    let refreshIntervalId = null;

    // 캐시 삭제 (실시간으로 삭제)
    const clearCache = (function () {
        if (!BORunning) {
            if (typeof (chrome.browsingData) !== "undefined") {
                BORunning = true;
                const millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;
                const oneWeekAgo = (new Date()).getTime() - millisecondsPerWeek;

                chrome.browsingData.removeCache({
                    "since": oneWeekAgo
                }, function () {
                    BORunning = false;
                });
            } else if (!alertThrown) {
                alertThrown = true;
                alert("fail!!!");
            }
        }
    });

    // 쿠키, 다운로드 기록, 인터넷 사용 기록 삭제 (한국 시간 00시와 12시에 실행)
    const clearBrowsingData = (function () {
        if (!BORunning) {
            if (typeof (chrome.browsingData) !== "undefined") {
                BORunning = true;
                chrome.browsingData.remove({
                    "since": 0
                }, {
                    "cookies": true,
                    "downloads": true,
                    "history": true
                }, function () {
                    BORunning = false;
                    console.log("Cookies, download history, and browsing history cleared");
                });
            } else if (!alertThrown) {
                alertThrown = true;
                alert("fail!!!");
            }
        }
    });

    // 한국 시간 기준 00시와 12시에 기록 삭제 스케쥴링
    const scheduleTwiceDailyClear = (function () {
        const now = new Date();
        const timeZoneOffset = now.getTimezoneOffset() * 60000;
        const koreaTimeOffset = 9 * 60 * 60000; // UTC+9
        const koreaNow = new Date(now.getTime() + koreaTimeOffset - timeZoneOffset);
        
        const nextMidnight = new Date(koreaNow.getFullYear(), koreaNow.getMonth(), koreaNow.getDate(), 0, 0, 0, 0);
        const nextNoon = new Date(koreaNow.getFullYear(), koreaNow.getMonth(), koreaNow.getDate(), 12, 0, 0, 0);

        if (koreaNow >= nextNoon) {
            nextMidnight.setDate(nextMidnight.getDate() + 1);
            nextNoon.setDate(nextNoon.getDate() + 1);
        } else if (koreaNow >= nextMidnight) {
            nextNoon.setDate(nextNoon.getDate() + 1);
        }

        const delayToMidnight = nextMidnight.getTime() - koreaNow.getTime();
        const delayToNoon = nextNoon.getTime() - koreaNow.getTime();

        chrome.alarms.create("midnightClear", { when: Date.now() + delayToMidnight, periodInMinutes: 720 });
        chrome.alarms.create("noonClear", { when: Date.now() + delayToNoon, periodInMinutes: 720 });
    });

    // 크롬 알람 API
    chrome.alarms.onAlarm.addListener(function (alarm) {
        if (alarm.name === "midnightClear" || alarm.name === "noonClear") {
            clearBrowsingData();
        }
    });

    const enableAct = (function () {
        BOEnabled = true;
        chrome.action.setIcon({ path: "icon_on.png" });
        chrome.action.setTitle({ title: "BO enabled" });
        refreshIntervalId = setInterval(clearCache, 10000); // 캐시를 실시간으로 주기적으로 삭제 (10초마다)
    });

    const disableAct = (function () {
        BOEnabled = false;
        chrome.action.setIcon({ path: "icon_off.png" });
        chrome.action.setTitle({ title: "BO disabled" });

        if (refreshIntervalId) {
            clearInterval(refreshIntervalId);
            refreshIntervalId = null;
        }
    });

    const flipStatus = (function () {
        if (BOEnabled) {
            disableAct();
        } else {
            enableAct();
        }
    });

    chrome.action.onClicked.addListener(flipStatus);

    if (localStorage["turnOnByDefault"] === "on") {
        enableAct();
    } else {
        disableAct();
    }

    fetch(localStorage["defaultSettingsUrl"])
        .then(data => data.text())
        .then(data => {
            const settings = JSON.parse(data);

            if (settings.enableOnStart === true) {
                disableAct();
            }

            if (settings.enableOnStart === false) {
                enableAct();
            }
        })
        .catch(() => {
            // do nothing
        });

    // 스크립트 시작 시 기록 삭제 예약 설정
    scheduleTwiceDailyClear();
})();
