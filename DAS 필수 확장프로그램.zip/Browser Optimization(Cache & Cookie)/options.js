const save = document.getElementById( "save" );
const enableOnStartElement = document.getElementById( "enableOnStartElement" );

async function saveOptions () {
    let newValue = "off";
    if ( enableOnStartElement.checked ) {
        newValue = "on";
    }
    await chrome.storage.local.set({
        turnOnByDefault: newValue,
    });
}

// Restores select box state to saved value from localStorage.
async function restoreOptions () {
    const localStorage = await chrome.storage.local.get();

    if ( localStorage["turnOnByDefault"] === "on" ) {
        enableOnStartElement.checked = true;
    }
}

save.addEventListener( "click", saveOptions );
restoreOptions();