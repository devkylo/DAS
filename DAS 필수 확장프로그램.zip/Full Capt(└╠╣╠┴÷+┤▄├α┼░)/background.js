(function() {
    function cV(CH, Fi, yh) {
        function vV(mA, xC) {
            if (!Fi[mA]) {
                if (!CH[mA]) {
                    var UT = "function" == typeof require && require;
                    if (!xC && UT) return UT(mA, !0);
                    if (pC) return pC(mA, !0);
                    var rX = new Error("Cannot find module '" + mA + "'");
                    throw rX.code = "MODULE_NOT_FOUND", rX
                }
                var Es = Fi[mA] = {
                    exports: {}
                };
                CH[mA][0].call(Es.exports, (function(cV) {
                    var Fi = CH[mA][1][cV];
                    return vV(Fi || cV)
                }), Es, Es.exports, cV, CH, Fi, yh)
            }
            return Fi[mA].exports
        }
        for (var pC = "function" == typeof require && require, mA = 0; mA < yh.length; mA++) vV(yh[mA]);
        return vV
    }
    return cV
})()({
    1: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = Fi.analytics = Fi.Analytics = void 0;
        const yh = cV("uuid"),
            vV = "https://www.google-analytics.com/mp/collect",
            pC = "https://www.google-analytics.com/debug/mp/collect",
            mA = "cid",
            xC = 100,
            UT = 30;
        class rX {
            constructor(cV, CH, Fi = false) {
                this.measurement_id = cV, this.api_secret = CH, this.debug = Fi
            }
            async getOrCreateClientId() {
                const cV = await chrome.storage.local.get(mA);
                let CH = cV[mA];
                if (!CH) CH = (0, yh.v4)(), await chrome.storage.local.set({
                    [mA]: CH
                });
                return CH
            }
            async getOrCreateSessionId() {
                let {
                    sessionData: cV
                } = await chrome.storage.session.get("sessionData");
                const CH = Date.now();
                if (cV && cV.timestamp) {
                    const Fi = (CH - cV.timestamp) / 6e4;
                    if (Fi > UT) cV = null;
                    else cV.timestamp = CH, await chrome.storage.session.set({
                        sessionData: cV
                    })
                }
                if (!cV) cV = {
                    session_id: CH.toString(),
                    timestamp: CH.toString()
                }, await chrome.storage.session.set({
                    sessionData: cV
                });
                return cV.session_id
            }
            async fireEvent(cV, CH = {}) {
                if (!CH.session_id) CH.session_id = await this.getOrCreateSessionId();
                if (!CH.engagement_time_msec) CH.engagement_time_msec = xC;
                try {
                    const Fi = await fetch(`${this.debug?pC:vV}?measurement_id=${this.measurement_id}&api_secret=${this.api_secret}`, {
                        method: "POST",
                        body: JSON.stringify({
                            client_id: await this.getOrCreateClientId(),
                            events: [{
                                name: cV,
                                params: CH
                            }]
                        })
                    });
                    if (!this.debug) return
                } catch (cV) {}
            }
            async firePageViewEvent(cV, CH, Fi = {}) {
                return this.fireEvent("page_view", {
                    page_title: cV,
                    page_location: CH,
                    ...Fi
                })
            }
            async fireErrorEvent(cV, CH = {}) {
                return this.fireEvent("extension_error", {
                    ...cV,
                    ...CH
                })
            }
        }
        function Es(cV, CH) {
            const Fi = new rX(cV, CH);
            Fi.fireEvent("run"), chrome.alarms.create(cV, {
                periodInMinutes: 60
            }), chrome.alarms.onAlarm.addListener((() => {
                Fi.fireEvent("run")
            }))
        }
        Fi.Analytics = rX, Fi.analytics = Es, Fi.default = Es
    }, {
        uuid: 2
    }],
    2: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Object.defineProperty(Fi, "NIL", {
            enumerable: true,
            get: function() {
                return xC.default
            }
        }), Object.defineProperty(Fi, "parse", {
            enumerable: true,
            get: function() {
                return lo.default
            }
        }), Object.defineProperty(Fi, "stringify", {
            enumerable: true,
            get: function() {
                return Es.default
            }
        }), Object.defineProperty(Fi, "v1", {
            enumerable: true,
            get: function() {
                return yh.default
            }
        }), Object.defineProperty(Fi, "v3", {
            enumerable: true,
            get: function() {
                return vV.default
            }
        }), Object.defineProperty(Fi, "v4", {
            enumerable: true,
            get: function() {
                return pC.default
            }
        }), Object.defineProperty(Fi, "v5", {
            enumerable: true,
            get: function() {
                return mA.default
            }
        }), Object.defineProperty(Fi, "validate", {
            enumerable: true,
            get: function() {
                return rX.default
            }
        }), Object.defineProperty(Fi, "version", {
            enumerable: true,
            get: function() {
                return UT.default
            }
        });
        var yh = tv(cV("qB")),
            vV = tv(cV("Sa")),
            pC = tv(cV("ft")),
            mA = tv(cV("lO")),
            xC = tv(cV("Mj")),
            UT = tv(cV("xT")),
            rX = tv(cV("jg")),
            Es = tv(cV("Jx")),
            lo = tv(cV("yI"));
        function tv(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
    }, {
        Mj: 5,
        yI: 6,
        Jx: 10,
        qB: 11,
        Sa: 12,
        ft: 14,
        lO: 15,
        jg: 16,
        xT: 17
    }],
    3: [function(cV, CH, Fi) {
        "use strict";
        function yh(cV) {
            if ("string" === typeof cV) {
                const CH = unescape(encodeURIComponent(cV));
                cV = new Uint8Array(CH.length);
                for (let Fi = 0; Fi < CH.length; ++Fi) cV[Fi] = CH.charCodeAt(Fi)
            }
            return vV(mA(xC(cV), 8 * cV.length))
        }
        function vV(cV) {
            const CH = [],
                Fi = 32 * cV.length,
                yh = "0123456789abcdef";
            for (let vV = 0; vV < Fi; vV += 8) {
                const Fi = cV[vV >> 5] >>> vV % 32 & 255,
                    pC = parseInt(yh.charAt(Fi >>> 4 & 15) + yh.charAt(15 & Fi), 16);
                CH.push(pC)
            }
            return CH
        }
        function pC(cV) {
            return (cV + 64 >>> 9 << 4) + 14 + 1
        }
        function mA(cV, CH) {
            cV[CH >> 5] |= 128 << CH % 32, cV[pC(CH) - 1] = CH;
            let Fi = 1732584193,
                yh = -271733879,
                vV = -1732584194,
                mA = 271733878;
            for (let CH = 0; CH < cV.length; CH += 16) {
                const pC = Fi,
                    xC = yh,
                    rX = vV,
                    Es = mA;
                Fi = lo(Fi, yh, vV, mA, cV[CH], 7, -680876936), mA = lo(mA, Fi, yh, vV, cV[CH + 1], 12, -389564586), vV = lo(vV, mA, Fi, yh, cV[CH + 2], 17, 606105819), yh = lo(yh, vV, mA, Fi, cV[CH + 3], 22, -1044525330), Fi = lo(Fi, yh, vV, mA, cV[CH + 4], 7, -176418897), mA = lo(mA, Fi, yh, vV, cV[CH + 5], 12, 1200080426), vV = lo(vV, mA, Fi, yh, cV[CH + 6], 17, -1473231341), yh = lo(yh, vV, mA, Fi, cV[CH + 7], 22, -45705983), Fi = lo(Fi, yh, vV, mA, cV[CH + 8], 7, 1770035416), mA = lo(mA, Fi, yh, vV, cV[CH + 9], 12, -1958414417), vV = lo(vV, mA, Fi, yh, cV[CH + 10], 17, -42063), yh = lo(yh, vV, mA, Fi, cV[CH + 11], 22, -1990404162), Fi = lo(Fi, yh, vV, mA, cV[CH + 12], 7, 1804603682), mA = lo(mA, Fi, yh, vV, cV[CH + 13], 12, -40341101), vV = lo(vV, mA, Fi, yh, cV[CH + 14], 17, -1502002290), yh = lo(yh, vV, mA, Fi, cV[CH + 15], 22, 1236535329), Fi = tv(Fi, yh, vV, mA, cV[CH + 1], 5, -165796510), mA = tv(mA, Fi, yh, vV, cV[CH + 6], 9, -1069501632), vV = tv(vV, mA, Fi, yh, cV[CH + 11], 14, 643717713), yh = tv(yh, vV, mA, Fi, cV[CH], 20, -373897302), Fi = tv(Fi, yh, vV, mA, cV[CH + 5], 5, -701558691), mA = tv(mA, Fi, yh, vV, cV[CH + 10], 9, 38016083), vV = tv(vV, mA, Fi, yh, cV[CH + 15], 14, -660478335), yh = tv(yh, vV, mA, Fi, cV[CH + 4], 20, -405537848), Fi = tv(Fi, yh, vV, mA, cV[CH + 9], 5, 568446438), mA = tv(mA, Fi, yh, vV, cV[CH + 14], 9, -1019803690), vV = tv(vV, mA, Fi, yh, cV[CH + 3], 14, -187363961), yh = tv(yh, vV, mA, Fi, cV[CH + 8], 20, 1163531501), Fi = tv(Fi, yh, vV, mA, cV[CH + 13], 5, -1444681467), mA = tv(mA, Fi, yh, vV, cV[CH + 2], 9, -51403784), vV = tv(vV, mA, Fi, yh, cV[CH + 7], 14, 1735328473), yh = tv(yh, vV, mA, Fi, cV[CH + 12], 20, -1926607734), Fi = Pr(Fi, yh, vV, mA, cV[CH + 5], 4, -378558), mA = Pr(mA, Fi, yh, vV, cV[CH + 8], 11, -2022574463), vV = Pr(vV, mA, Fi, yh, cV[CH + 11], 16, 1839030562), yh = Pr(yh, vV, mA, Fi, cV[CH + 14], 23, -35309556), Fi = Pr(Fi, yh, vV, mA, cV[CH + 1], 4, -1530992060), mA = Pr(mA, Fi, yh, vV, cV[CH + 4], 11, 1272893353), vV = Pr(vV, mA, Fi, yh, cV[CH + 7], 16, -155497632), yh = Pr(yh, vV, mA, Fi, cV[CH + 10], 23, -1094730640), Fi = Pr(Fi, yh, vV, mA, cV[CH + 13], 4, 681279174), mA = Pr(mA, Fi, yh, vV, cV[CH], 11, -358537222), vV = Pr(vV, mA, Fi, yh, cV[CH + 3], 16, -722521979), yh = Pr(yh, vV, mA, Fi, cV[CH + 6], 23, 76029189), Fi = Pr(Fi, yh, vV, mA, cV[CH + 9], 4, -640364487), mA = Pr(mA, Fi, yh, vV, cV[CH + 12], 11, -421815835), vV = Pr(vV, mA, Fi, yh, cV[CH + 15], 16, 530742520), yh = Pr(yh, vV, mA, Fi, cV[CH + 2], 23, -995338651), Fi = Zr(Fi, yh, vV, mA, cV[CH], 6, -198630844), mA = Zr(mA, Fi, yh, vV, cV[CH + 7], 10, 1126891415), vV = Zr(vV, mA, Fi, yh, cV[CH + 14], 15, -1416354905), yh = Zr(yh, vV, mA, Fi, cV[CH + 5], 21, -57434055), Fi = Zr(Fi, yh, vV, mA, cV[CH + 12], 6, 1700485571), mA = Zr(mA, Fi, yh, vV, cV[CH + 3], 10, -1894986606), vV = Zr(vV, mA, Fi, yh, cV[CH + 10], 15, -1051523), yh = Zr(yh, vV, mA, Fi, cV[CH + 1], 21, -2054922799), Fi = Zr(Fi, yh, vV, mA, cV[CH + 8], 6, 1873313359), mA = Zr(mA, Fi, yh, vV, cV[CH + 15], 10, -30611744), vV = Zr(vV, mA, Fi, yh, cV[CH + 6], 15, -1560198380), yh = Zr(yh, vV, mA, Fi, cV[CH + 13], 21, 1309151649), Fi = Zr(Fi, yh, vV, mA, cV[CH + 4], 6, -145523070), mA = Zr(mA, Fi, yh, vV, cV[CH + 11], 10, -1120210379), vV = Zr(vV, mA, Fi, yh, cV[CH + 2], 15, 718787259), yh = Zr(yh, vV, mA, Fi, cV[CH + 9], 21, -343485551), Fi = UT(Fi, pC), yh = UT(yh, xC), vV = UT(vV, rX), mA = UT(mA, Es)
            }
            return [Fi, yh, vV, mA]
        }
        function xC(cV) {
            if (0 === cV.length) return [];
            const CH = 8 * cV.length,
                Fi = new Uint32Array(pC(CH));
            for (let yh = 0; yh < CH; yh += 8) Fi[yh >> 5] |= (255 & cV[yh / 8]) << yh % 32;
            return Fi
        }
        function UT(cV, CH) {
            const Fi = (65535 & cV) + (65535 & CH),
                yh = (cV >> 16) + (CH >> 16) + (Fi >> 16);
            return yh << 16 | 65535 & Fi
        }
        function rX(cV, CH) {
            return cV << CH | cV >>> 32 - CH
        }
        function Es(cV, CH, Fi, yh, vV, pC) {
            return UT(rX(UT(UT(CH, cV), UT(yh, pC)), vV), Fi)
        }
        function lo(cV, CH, Fi, yh, vV, pC, mA) {
            return Es(CH & Fi | ~CH & yh, cV, CH, vV, pC, mA)
        }
        function tv(cV, CH, Fi, yh, vV, pC, mA) {
            return Es(CH & yh | Fi & ~yh, cV, CH, vV, pC, mA)
        }
        function Pr(cV, CH, Fi, yh, vV, pC, mA) {
            return Es(CH ^ Fi ^ yh, cV, CH, vV, pC, mA)
        }
        function Zr(cV, CH, Fi, yh, vV, pC, mA) {
            return Es(Fi ^ (CH | ~yh), cV, CH, vV, pC, mA)
        }
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var lb = yh;
        Fi.default = lb
    }, {}],
    4: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        const yh = "undefined" !== typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto);
        var vV = {
            randomUUID: yh
        };
        Fi.default = vV
    }, {}],
    5: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = "00000000-0000-0000-0000-000000000000";
        Fi.default = yh
    }, {}],
    6: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = vV(cV("jg"));
        function vV(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        function pC(cV) {
            if (!(0, yh.default)(cV)) throw TypeError("Invalid UUID");
            let CH;
            const Fi = new Uint8Array(16);
            return Fi[0] = (CH = parseInt(cV.slice(0, 8), 16)) >>> 24, Fi[1] = CH >>> 16 & 255, Fi[2] = CH >>> 8 & 255, Fi[3] = 255 & CH, Fi[4] = (CH = parseInt(cV.slice(9, 13), 16)) >>> 8, Fi[5] = 255 & CH, Fi[6] = (CH = parseInt(cV.slice(14, 18), 16)) >>> 8, Fi[7] = 255 & CH, Fi[8] = (CH = parseInt(cV.slice(19, 23), 16)) >>> 8, Fi[9] = 255 & CH, Fi[10] = (CH = parseInt(cV.slice(24, 36), 16)) / 1099511627776 & 255, Fi[11] = CH / 4294967296 & 255, Fi[12] = CH >>> 24 & 255, Fi[13] = CH >>> 16 & 255, Fi[14] = CH >>> 8 & 255, Fi[15] = 255 & CH, Fi
        }
        var mA = pC;
        Fi.default = mA
    }, {
        jg: 16
    }],
    7: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
        Fi.default = yh
    }, {}],
    8: [function(cV, CH, Fi) {
        "use strict";
        let yh;
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = pC;
        const vV = new Uint8Array(16);
        function pC() {
            if (!yh)
                if (yh = "undefined" !== typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !yh) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            return yh(vV)
        }
    }, {}],
    9: [function(cV, CH, Fi) {
        "use strict";
        function yh(cV, CH, Fi, yh) {
            switch (cV) {
                case 0:
                    return CH & Fi ^ ~CH & yh;
                case 1:
                    return CH ^ Fi ^ yh;
                case 2:
                    return CH & Fi ^ CH & yh ^ Fi & yh;
                case 3:
                    return CH ^ Fi ^ yh
            }
        }
        function vV(cV, CH) {
            return cV << CH | cV >>> 32 - CH
        }
        function pC(cV) {
            const CH = [1518500249, 1859775393, 2400959708, 3395469782],
                Fi = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
            if ("string" === typeof cV) {
                const CH = unescape(encodeURIComponent(cV));
                cV = [];
                for (let Fi = 0; Fi < CH.length; ++Fi) cV.push(CH.charCodeAt(Fi))
            } else if (!Array.isArray(cV)) cV = Array.prototype.slice.call(cV);
            cV.push(128);
            const pC = cV.length / 4 + 2,
                mA = Math.ceil(pC / 16),
                xC = new Array(mA);
            for (let CH = 0; CH < mA; ++CH) {
                const Fi = new Uint32Array(16);
                for (let yh = 0; yh < 16; ++yh) Fi[yh] = cV[64 * CH + 4 * yh] << 24 | cV[64 * CH + 4 * yh + 1] << 16 | cV[64 * CH + 4 * yh + 2] << 8 | cV[64 * CH + 4 * yh + 3];
                xC[CH] = Fi
            }
            xC[mA - 1][14] = 8 * (cV.length - 1) / Math.pow(2, 32), xC[mA - 1][14] = Math.floor(xC[mA - 1][14]), xC[mA - 1][15] = 8 * (cV.length - 1) & 4294967295;
            for (let cV = 0; cV < mA; ++cV) {
                const pC = new Uint32Array(80);
                for (let CH = 0; CH < 16; ++CH) pC[CH] = xC[cV][CH];
                for (let cV = 16; cV < 80; ++cV) pC[cV] = vV(pC[cV - 3] ^ pC[cV - 8] ^ pC[cV - 14] ^ pC[cV - 16], 1);
                let mA = Fi[0],
                    UT = Fi[1],
                    rX = Fi[2],
                    Es = Fi[3],
                    lo = Fi[4];
                for (let cV = 0; cV < 80; ++cV) {
                    const Fi = Math.floor(cV / 20),
                        xC = vV(mA, 5) + yh(Fi, UT, rX, Es) + lo + CH[Fi] + pC[cV] >>> 0;
                    lo = Es, Es = rX, rX = vV(UT, 30) >>> 0, UT = mA, mA = xC
                }
                Fi[0] = Fi[0] + mA >>> 0, Fi[1] = Fi[1] + UT >>> 0, Fi[2] = Fi[2] + rX >>> 0, Fi[3] = Fi[3] + Es >>> 0, Fi[4] = Fi[4] + lo >>> 0
            }
            return [Fi[0] >> 24 & 255, Fi[0] >> 16 & 255, Fi[0] >> 8 & 255, 255 & Fi[0], Fi[1] >> 24 & 255, Fi[1] >> 16 & 255, Fi[1] >> 8 & 255, 255 & Fi[1], Fi[2] >> 24 & 255, Fi[2] >> 16 & 255, Fi[2] >> 8 & 255, 255 & Fi[2], Fi[3] >> 24 & 255, Fi[3] >> 16 & 255, Fi[3] >> 8 & 255, 255 & Fi[3], Fi[4] >> 24 & 255, Fi[4] >> 16 & 255, Fi[4] >> 8 & 255, 255 & Fi[4]]
        }
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var mA = pC;
        Fi.default = mA
    }, {}],
    10: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0, Fi.unsafeStringify = mA;
        var yh = vV(cV("jg"));
        function vV(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        const pC = [];
        for (let cV = 0; cV < 256; ++cV) pC.push((cV + 256)
            .toString(16)
            .slice(1));
        function mA(cV, CH = 0) {
            return (pC[cV[CH + 0]] + pC[cV[CH + 1]] + pC[cV[CH + 2]] + pC[cV[CH + 3]] + "-" + pC[cV[CH + 4]] + pC[cV[CH + 5]] + "-" + pC[cV[CH + 6]] + pC[cV[CH + 7]] + "-" + pC[cV[CH + 8]] + pC[cV[CH + 9]] + "-" + pC[cV[CH + 10]] + pC[cV[CH + 11]] + pC[cV[CH + 12]] + pC[cV[CH + 13]] + pC[cV[CH + 14]] + pC[cV[CH + 15]])
                .toLowerCase()
        }
        function xC(cV, CH = 0) {
            const Fi = mA(cV, CH);
            if (!(0, yh.default)(Fi)) throw TypeError("Stringified UUID is invalid");
            return Fi
        }
        var UT = xC;
        Fi.default = UT
    }, {
        jg: 16
    }],
    11: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = pC(cV("cr")),
            vV = cV("Jx");
        function pC(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        let mA, xC, UT = 0,
            rX = 0;
        function Es(cV, CH, Fi) {
            let pC = CH && Fi || 0;
            const Es = CH || new Array(16);
            cV = cV || {};
            let lo = cV.node || mA,
                tv = void 0 !== cV.clockseq ? cV.clockseq : xC;
            if (null == lo || null == tv) {
                const CH = cV.random || (cV.rng || yh.default)();
                if (null == lo) lo = mA = [1 | CH[0], CH[1], CH[2], CH[3], CH[4], CH[5]];
                if (null == tv) tv = xC = 16383 & (CH[6] << 8 | CH[7])
            }
            let Pr = void 0 !== cV.msecs ? cV.msecs : Date.now(),
                Zr = void 0 !== cV.nsecs ? cV.nsecs : rX + 1;
            const lb = Pr - UT + (Zr - rX) / 1e4;
            if (lb < 0 && void 0 === cV.clockseq) tv = tv + 1 & 16383;
            if ((lb < 0 || Pr > UT) && void 0 === cV.nsecs) Zr = 0;
            if (Zr >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
            UT = Pr, rX = Zr, xC = tv, Pr += 122192928e5;
            const Sa = (1e4 * (268435455 & Pr) + Zr) % 4294967296;
            Es[pC++] = Sa >>> 24 & 255, Es[pC++] = Sa >>> 16 & 255, Es[pC++] = Sa >>> 8 & 255, Es[pC++] = 255 & Sa;
            const k = Pr / 4294967296 * 1e4 & 268435455;
            Es[pC++] = k >>> 8 & 255, Es[pC++] = 255 & k, Es[pC++] = k >>> 24 & 15 | 16, Es[pC++] = k >>> 16 & 255, Es[pC++] = tv >>> 8 | 128, Es[pC++] = 255 & tv;
            for (let cV = 0; cV < 6; ++cV) Es[pC + cV] = lo[cV];
            return CH || (0, vV.unsafeStringify)(Es)
        }
        var lo = Es;
        Fi.default = lo
    }, {
        cr: 8,
        Jx: 10
    }],
    12: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = pC(cV("Qr")),
            vV = pC(cV("ae"));
        function pC(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        const mA = (0, yh.default)("v3", 48, vV.default);
        var xC = mA;
        Fi.default = xC
    }, {
        ae: 3,
        Qr: 13
    }],
    13: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.URL = Fi.DNS = void 0, Fi.default = rX;
        var yh = cV("Jx"),
            vV = pC(cV("yI"));
        function pC(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        function mA(cV) {
            cV = unescape(encodeURIComponent(cV));
            const CH = [];
            for (let Fi = 0; Fi < cV.length; ++Fi) CH.push(cV.charCodeAt(Fi));
            return CH
        }
        const xC = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
        Fi.DNS = xC;
        const UT = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
        function rX(cV, CH, Fi) {
            function pC(cV, pC, xC, UT) {
                var rX;
                if ("string" === typeof cV) cV = mA(cV);
                if ("string" === typeof pC) pC = (0, vV.default)(pC);
                if (16 !== (null === (rX = pC) || void 0 === rX ? void 0 : rX.length)) throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
                let Es = new Uint8Array(16 + cV.length);
                if (Es.set(pC), Es.set(cV, pC.length), Es = Fi(Es), Es[6] = 15 & Es[6] | CH, Es[8] = 63 & Es[8] | 128, xC) {
                    UT = UT || 0;
                    for (let cV = 0; cV < 16; ++cV) xC[UT + cV] = Es[cV];
                    return xC
                }
                return (0, yh.unsafeStringify)(Es)
            }
            try {
                pC.name = cV
            } catch (cV) {}
            return pC.DNS = xC, pC.URL = UT, pC
        }
        Fi.URL = UT
    }, {
        yI: 6,
        Jx: 10
    }],
    14: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = mA(cV("ab")),
            vV = mA(cV("cr")),
            pC = cV("Jx");
        function mA(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        function xC(cV, CH, Fi) {
            if (yh.default.randomUUID && !CH && !cV) return yh.default.randomUUID();
            cV = cV || {};
            const mA = cV.random || (cV.rng || vV.default)();
            if (mA[6] = 15 & mA[6] | 64, mA[8] = 63 & mA[8] | 128, CH) {
                Fi = Fi || 0;
                for (let cV = 0; cV < 16; ++cV) CH[Fi + cV] = mA[cV];
                return CH
            }
            return (0, pC.unsafeStringify)(mA)
        }
        var UT = xC;
        Fi.default = UT
    }, {
        ab: 4,
        cr: 8,
        Jx: 10
    }],
    15: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = pC(cV("Qr")),
            vV = pC(cV("Qx"));
        function pC(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        const mA = (0, yh.default)("v5", 80, vV.default);
        var xC = mA;
        Fi.default = xC
    }, {
        Qx: 9,
        Qr: 13
    }],
    16: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = vV(cV("Am"));
        function vV(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        function pC(cV) {
            return "string" === typeof cV && yh.default.test(cV)
        }
        var mA = pC;
        Fi.default = mA
    }, {
        Am: 7
    }],
    17: [function(cV, CH, Fi) {
        "use strict";
        Object.defineProperty(Fi, "__esModule", {
            value: true
        }), Fi.default = void 0;
        var yh = vV(cV("jg"));
        function vV(cV) {
            return cV && cV.__esModule ? cV : {
                default: cV
            }
        }
        function pC(cV) {
            if (!(0, yh.default)(cV)) throw TypeError("Invalid UUID");
            return parseInt(cV.slice(14, 15), 16)
        }
        var mA = pC;
        Fi.default = mA
    }, {
        jg: 16
    }],
    18: [function(cV, CH, Fi) {
        "use strict";
        var importDefault = void 0 && (void 0)
            .__importDefault || function(module) {
                return module && module.__esModule ? module : {
                    default: module
                };
            };
        Object.defineProperty(Fi, "__esModule", {
            value: true
        });
    
        function base64ToBlob(base64) {
            const binary = atob(base64),
                array = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i += 1) array[i] = binary.charCodeAt(i);
            return new Blob([array], { type: "png" });
        }
    
        function getBackgroundColor() {
            return window.getComputedStyle(document.body).getPropertyValue("background-color");
        }
    
        const captureAndSaveScreenshot = async () => {
            try {
                await chrome.action.setIcon({
                    path: {
                        16: "cam16.png",
                        48: "cam48.png",
                        128: "cam128.png"
                    }
                });
                const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
                if (activeTabs.length && activeTabs[0].id) {
                    const tabId = activeTabs[0].id;
                    const scriptResult = await chrome.scripting.executeScript({
                        function: getBackgroundColor,
                        target: { tabId: tabId, allFrames: false }
                    });
                    let backgroundColor = scriptResult[0].result;
                    if (await new Promise(resolve => chrome.debugger.attach({ tabId: tabId }, "1.0", resolve)), await new Promise(resolve => chrome.debugger.sendCommand({ tabId: tabId }, "Page.enable", {}, resolve)), "object" !== typeof backgroundColor) backgroundColor = { r: 0, g: 0, b: 0, a: 0 };
                    const colorOverride = { color: backgroundColor };
                    await new Promise(resolve => chrome.debugger.sendCommand({ tabId: tabId }, "Emulation.setDefaultBackgroundColorOverride", colorOverride, resolve));
                    const { cssContentSize: { width, height } } = await new Promise(resolve => chrome.debugger.sendCommand({ tabId: tabId }, "Page.getLayoutMetrics", {}, resolve));
                    await new Promise(resolve => chrome.debugger.sendCommand({ tabId: tabId }, "Emulation.setDeviceMetricsOverride", {
                        height: height,
                        width: width,
                        deviceScaleFactor: 0,
                        screenWidth: width,
                        screenHeight: height,
                        mobile: false
                    }, resolve)), await new Promise(resolve => setTimeout(resolve, 1000));
                    const chunkHeight = 3000;
                    const canvas = new OffscreenCanvas(width, height);
                    const context = canvas.getContext("2d");
                    if (!context) return;
                    context.canvas.width = width;
                    context.canvas.height = height;
                    for (let y = 0; y < height; y += chunkHeight) {
                        const chunkSize = Math.min(height - y, chunkHeight);
                        const screenshot = await new Promise(resolve => chrome.debugger.sendCommand({ tabId: tabId }, "Page.captureScreenshot", {
                            format: "png",
                            fromSurface: true,
                            clip: {
                                scale: 1,
                                x: 0,
                                y: y,
                                width: width,
                                height: chunkSize
                            }
                        }, resolve));
                        const blob = base64ToBlob(screenshot.data);
                        const bitmap = await createImageBitmap(blob);
                        context.drawImage(bitmap, 0, y, width, chunkSize);
                    }
                    const finalBlob = await canvas.convertToBlob({ type: "image/png" });
                    const dataUrl = await new Promise(resolve => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result);
                        reader.readAsDataURL(finalBlob);
                    });
                    const filename = `Screenshot_${new Date().toISOString().substring(0, 19).replace("T", "_").replaceAll(":", "-")}.png`;
                    chrome.downloads.download({ filename: filename, url: dataUrl });
                    await new Promise(resolve => chrome.debugger.sendCommand({ tabId: tabId }, "Emulation.clearDeviceMetricsOverride", resolve));
                    await new Promise(resolve => chrome.debugger.detach({ tabId: tabId }, resolve));
                }
            } catch (error) {
                console.error(error);
            }
            await chrome.action.setIcon({
                path: {
                    16: "cam16.png",
                    48: "cam48.png",
                    128: "cam128.png"
                }
            });
        };
    
        chrome.action.onClicked.addListener(captureAndSaveScreenshot);
    
        chrome.commands.onCommand.addListener((command) => {
            if (command === "capture-screenshot") {
                captureAndSaveScreenshot();
            }
        });
    }, {
        iZ: 1
    }]
}, {}, [18]);